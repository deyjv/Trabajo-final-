/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabajo_final;

/**
 *
 * @author deisy
 */
public class Trabajo_FINAL {

   
public class Avion {
    private String idAvion;
    private String modelo;
    private int capacidadEjecutiva = 2;
    private int capacidadEconomica = 2;
    private int disponiblesEjecutiva = 2;
    private int disponiblesEconomica = 2;

    public Avion(String idAvion, String modelo) {
        this.idAvion = idAvion;
        this.modelo = modelo;
    }

    public boolean verificarDisponibilidad(String clase) {
        if (clase.equalsIgnoreCase("ejecutiva")) {
            return disponiblesEjecutiva > 0;
        } else {
            return disponiblesEconomica > 0;
        }
    }

    public void ocuparAsiento(String clase) {
        if (clase.equalsIgnoreCase("ejecutiva") && disponiblesEjecutiva > 0) {
            disponiblesEjecutiva--;
        } else if (clase.equalsIgnoreCase("economica") && disponiblesEconomica > 0) {
            disponiblesEconomica--;
        }
    }

    public String getIdAvion() { return idAvion; }
}
// Archivo: Vuelo.java
public class Vuelo {
    private String idVuelo;
    private String origen;
    private String destino;
    private String fecha;
    private Avion avion;
    private double precioEjecutiva;
    private double precioEconomica;

    public Vuelo(String idVuelo, String origen, String destino, String fecha, Avion avion,
                 double precioEjecutiva, double precioEconomica) {
        this.idVuelo = idVuelo;
        this.origen = origen;
        this.destino = destino;
        this.fecha = fecha;
        this.avion = avion;
        this.precioEjecutiva = precioEjecutiva;
        this.precioEconomica = precioEconomica;
    }

    public void mostrarInfo() {
        System.out.println("Vuelo " + idVuelo + ": " + origen + " -> " + destino + " (" + fecha + ")");
    }

    public Avion getAvion() { return avion; }
    public double getPrecio(String clase) {
        return clase.equalsIgnoreCase("ejecutiva") ? precioEjecutiva : precioEconomica;
    }
}
    
}
